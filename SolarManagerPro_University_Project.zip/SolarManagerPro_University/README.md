# Solar Manager Pro — University Project

IoT-based monitoring prototype for a 12 V, 25 W solar system:
- Solar panel 1: 10 W
- Solar panel 2: 10 W
- Solar panel 3: 5 W
- ESP32-WROOM + individual voltage/current sensors
- Wi-Fi with Home Wi-Fi and mobile-hotspot profiles
- FastAPI cloud backend + database
- Android app (Kotlin + Jetpack Compose)
- GitHub Actions debug APK build

## Important project status
This is a source-code starter for an academic prototype, not a tested commercial product.
The Android app includes a dashboard, site/device screens, connectivity settings and API configuration.
The ESP32 firmware sends measurements to the backend using HTTPS. This keeps the first prototype easier to deploy on free-tier hosting than requiring a permanently running MQTT broker. MQTT is listed as a future/optional transport in the architecture; it is not enabled in this initial firmware.
The backend defaults to SQLite for local testing. For a hosted deployment, set `DATABASE_URL` to a managed PostgreSQL connection string. Free hosting plans can sleep, have quotas, or change; remote monitoring requires an active internet connection and a running backend.

## Repository structure
- `android/` — Android Studio project
- `backend/` — FastAPI API and database
- `esp32/` — Arduino firmware
- `.github/workflows/android-apk.yml` — GitHub Actions APK build

## 1. Run backend locally
```bash
cd backend
python -m venv .venv
# Windows: .venv\Scripts\activate
# Linux/macOS: source .venv/bin/activate
pip install -r requirements.txt
export DEVICE_API_TOKEN="change-this-device-token"
uvicorn app.main:app --host 0.0.0.0 --port 8000
```
Open `http://localhost:8000/docs`.

For deployment, configure:
- `DEVICE_API_TOKEN`: long random secret shared with ESP32
- `DATABASE_URL`: PostgreSQL URL from your managed database provider (optional locally)
- `CORS_ORIGINS`: comma-separated allowed origins (for a web client; Android native apps are not browser-CORS constrained)

Deploy the `backend/` directory as a Python web service with start command:
`uvicorn app.main:app --host 0.0.0.0 --port $PORT`

After deployment, test:
`GET https://YOUR-SERVICE-URL/health`

## 2. Configure ESP32
Install Arduino IDE and these libraries:
- Adafruit INA219
- ArduinoJson

Open `esp32/SolarManagerPro.ino`, set:
- `HOME_SSID`, `HOME_PASSWORD`
- `HOTSPOT_SSID`, `HOTSPOT_PASSWORD`
- `API_URL` to `https://YOUR-SERVICE-URL/api/v1/telemetry`
- `DEVICE_TOKEN` to the same value as backend `DEVICE_API_TOKEN`

The code expects four INA219-compatible current/voltage monitor modules on the same I2C bus:
- Panel 1 at address `0x40`
- Panel 2 at address `0x41`
- Panel 3 at address `0x44`
- Battery at address `0x45`

Set each sensor module's address jumpers accordingly. Verify your specific breakout board supports these addresses. The battery sensor must be installed in the correct series path by someone competent to work on the system. The firmware reports battery current as a signed measurement; validate sensor polarity.

ESP32 I2C defaults:
- SDA GPIO 21
- SCL GPIO 22

Power ESP32 from a regulated 5 V buck converter connected to the 12 V system, not directly from a solar panel or battery. Use appropriate fuse/protection. Never connect panel/battery voltage directly to GPIO pins.

## 3. Build Android APK with GitHub
1. Create a GitHub repository.
2. Upload the *contents* of this project folder to the repository root (including hidden `.github` folder).
3. Open **Actions** and run `Android Debug APK`.
4. Download the `SolarManagerPro-debug-apk` artifact from the successful workflow.
5. Extract it to get `app-debug.apk`.

Android app server configuration:
- Open app > Settings > Server Configuration.
- Enter your deployed backend URL, e.g. `https://your-service.onrender.com`.
- Save it. The app reads telemetry from `/api/v1/telemetry/latest`.

## 4. Data format
ESP32 posts JSON like:
```json
{
  "device_id": "solar-esp32-01",
  "site_id": "my-home",
  "timestamp": "2026-11-26T10:00:00Z",
  "panels": [
    {"panel_id":"P1","voltage_v":18.2,"current_a":0.52,"power_w":9.46},
    {"panel_id":"P2","voltage_v":18.1,"current_a":0.50,"power_w":9.05},
    {"panel_id":"P3","voltage_v":17.9,"current_a":0.24,"power_w":4.30}
  ],
  "battery": {"voltage_v":12.6,"current_a":0.35}
}
```
Values above are illustrative only, not expected measured results.

## 5. Electrical safety and measurement notes
- Confirm each panel's Vmp/Voc and polarity before wiring.
- Do not parallel panels with incompatible operating voltages without checking their datasheets and charge-controller requirements.
- Use a suitable 12 V charge controller between PV and battery.
- Choose sensor modules/shunts for the actual maximum panel and battery current. INA219 modules are often limited by their onboard shunt and layout; check ratings.
- Use fuses, insulated terminals, correct wire gauge and reverse-polarity protection.
- Do not modify mains/grid wiring. Keep this project on the low-voltage DC side.
- A 12 V battery can deliver very high fault current. Avoid short circuits.

## 6. Current limitations
- Login is a UI placeholder; production user authentication and per-user permissions are not implemented.
- The app currently reads the latest site telemetry from the API; dashboard charts use the returned readings / placeholders where data is unavailable.
- Wi-Fi credentials in this example are compile-time placeholders in firmware. For a real provisioning flow, add a captive portal or BLE provisioning and store credentials securely.
- Automatic failover tries the Home Wi-Fi profile first, then the hotspot profile at boot/reconnect. It does not scan for the strongest network continuously.
- Cloud hosting and database accounts must be created and configured by the project owner. No hosting credentials are embedded.
- This is an educational prototype; validate sensor calibration and all electrical connections before powering the setup.
