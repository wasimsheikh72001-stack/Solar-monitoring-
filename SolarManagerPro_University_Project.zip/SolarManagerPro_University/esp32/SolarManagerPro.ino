#include <WiFi.h>
#include <WiFiMulti.h>
#include <HTTPClient.h>
#include <WiFiClientSecure.h>
#include <Wire.h>
#include <Adafruit_INA219.h>
#include <ArduinoJson.h>
#include <time.h>

// Configure these values before flashing. Do not publish real passwords/tokens to GitHub.
const char* HOME_SSID = "YOUR_HOME_WIFI";
const char* HOME_PASSWORD = "YOUR_HOME_PASSWORD";
const char* HOTSPOT_SSID = "YOUR_PHONE_HOTSPOT";
const char* HOTSPOT_PASSWORD = "YOUR_HOTSPOT_PASSWORD";

const char* API_URL = "https://YOUR-BACKEND.example.com/api/v1/telemetry";
const char* DEVICE_TOKEN = "REPLACE_WITH_DEVICE_API_TOKEN";
const char* DEVICE_ID = "solar-esp32-01";
const char* SITE_ID = "my-home";

WiFiMulti wifiMulti;
Adafruit_INA219 panel1(0x40);
Adafruit_INA219 panel2(0x41);
Adafruit_INA219 panel3(0x44);
Adafruit_INA219 batterySensor(0x45);

unsigned long lastSend = 0;
const unsigned long SEND_INTERVAL_MS = 10000;

struct Reading {
  float voltage;
  float current;
  float power;
};

Reading readSensor(Adafruit_INA219 &sensor) {
  Reading r;
  r.voltage = sensor.getBusVoltage_V() + sensor.getShuntVoltage_mV() / 1000.0f;
  r.current = sensor.getCurrent_mA() / 1000.0f;
  r.power = r.voltage * r.current;
  return r;
}

void connectNetworks() {
  WiFi.mode(WIFI_STA);
  wifiMulti.addAP(HOME_SSID, HOME_PASSWORD);
  wifiMulti.addAP(HOTSPOT_SSID, HOTSPOT_PASSWORD);
  Serial.println("Connecting to configured Wi-Fi profiles...");
  unsigned long start = millis();
  while (wifiMulti.run() != WL_CONNECTED && millis() - start < 30000) {
    delay(500);
    Serial.print(".");
  }
  Serial.println();
  if (WiFi.status() == WL_CONNECTED) {
    Serial.print("Connected. IP: ");
    Serial.println(WiFi.localIP());
    configTime(0, 0, "pool.ntp.org", "time.nist.gov");
  } else {
    Serial.println("No Wi-Fi. Will retry in loop.");
  }
}

void setup() {
  Serial.begin(115200);
  Wire.begin(21, 22);
  if (!panel1.begin() || !panel2.begin() || !panel3.begin() || !batterySensor.begin()) {
    Serial.println("Sensor initialization failed. Check I2C wiring and sensor addresses.");
    while (true) delay(1000);
  }
  connectNetworks();
}

void sendTelemetry() {
  Reading p1 = readSensor(panel1);
  Reading p2 = readSensor(panel2);
  Reading p3 = readSensor(panel3);
  Reading bat = readSensor(batterySensor);
  // PV channels should be positive; preserve signed battery current for charge/discharge direction.
  if (p1.current < 0) p1.current = 0;
  if (p2.current < 0) p2.current = 0;
  if (p3.current < 0) p3.current = 0;
  p1.power = p1.voltage * p1.current;
  p2.power = p2.voltage * p2.current;
  p3.power = p3.voltage * p3.current;

  StaticJsonDocument<1024> doc;
  doc["device_id"] = DEVICE_ID;
  doc["site_id"] = SITE_ID;
  // Omit timestamp: backend assigns server UTC time.
  JsonArray panels = doc.createNestedArray("panels");
  JsonObject a = panels.createNestedObject();
  a["panel_id"] = "P1"; a["voltage_v"] = p1.voltage; a["current_a"] = p1.current; a["power_w"] = p1.power;
  JsonObject b = panels.createNestedObject();
  b["panel_id"] = "P2"; b["voltage_v"] = p2.voltage; b["current_a"] = p2.current; b["power_w"] = p2.power;
  JsonObject c = panels.createNestedObject();
  c["panel_id"] = "P3"; c["voltage_v"] = p3.voltage; c["current_a"] = p3.current; c["power_w"] = p3.power;
  JsonObject battery = doc.createNestedObject("battery");
  battery["voltage_v"] = bat.voltage;
  battery["current_a"] = bat.current;

  String body;
  serializeJson(doc, body);

  WiFiClientSecure client;
  client.setInsecure(); // Academic prototype only. Use certificate validation for a real deployment.
  HTTPClient https;
  if (https.begin(client, API_URL)) {
    https.addHeader("Content-Type", "application/json");
    https.addHeader("X-Device-Token", DEVICE_TOKEN);
    int code = https.POST(body);
    Serial.printf("Telemetry HTTP response: %d\n", code);
    if (code > 0) Serial.println(https.getString());
    https.end();
  }
}

void loop() {
  if (WiFi.status() != WL_CONNECTED) {
    wifiMulti.run();
    if (WiFi.status() != WL_CONNECTED) {
      delay(1000);
      return;
    }
  }
  if (millis() - lastSend >= SEND_INTERVAL_MS) {
    lastSend = millis();
    sendTelemetry();
  }
  delay(50);
}
