import os
from datetime import datetime, timezone
from typing import Optional

from fastapi import FastAPI, Header, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from sqlalchemy import create_engine, Column, Integer, String, Float, DateTime, JSON, desc
from sqlalchemy.orm import declarative_base, sessionmaker

DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///./solar_manager.db")
if DATABASE_URL.startswith("postgres://"):
    DATABASE_URL = DATABASE_URL.replace("postgres://", "postgresql+psycopg://", 1)
elif DATABASE_URL.startswith("postgresql://"):
    DATABASE_URL = DATABASE_URL.replace("postgresql://", "postgresql+psycopg://", 1)

connect_args = {"check_same_thread": False} if DATABASE_URL.startswith("sqlite") else {}
engine = create_engine(DATABASE_URL, connect_args=connect_args, pool_pre_ping=True)
SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False)
Base = declarative_base()

DEVICE_TOKEN = os.getenv("DEVICE_API_TOKEN", "dev-only-change-me")

class Telemetry(Base):
    __tablename__ = "telemetry"
    id = Column(Integer, primary_key=True, index=True)
    device_id = Column(String(80), index=True, nullable=False)
    site_id = Column(String(80), index=True, nullable=False)
    timestamp = Column(DateTime(timezone=True), index=True, nullable=False)
    total_power_w = Column(Float, nullable=False, default=0)
    panels = Column(JSON, nullable=False)
    battery = Column(JSON, nullable=False)

Base.metadata.create_all(bind=engine)

class Panel(BaseModel):
    panel_id: str
    voltage_v: float = Field(ge=0, le=60)
    current_a: float = Field(ge=0, le=20)
    power_w: float = Field(ge=0, le=500)

class Battery(BaseModel):
    voltage_v: float = Field(ge=0, le=30)
    current_a: float = Field(ge=-100, le=100)

class TelemetryIn(BaseModel):
    device_id: str = Field(min_length=1, max_length=80)
    site_id: str = Field(min_length=1, max_length=80)
    timestamp: Optional[datetime] = None
    panels: list[Panel]
    battery: Battery

app = FastAPI(title="Solar Manager Pro API", version="1.0.0")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=False,
    allow_methods=["GET", "POST"],
    allow_headers=["*"],
)

@app.get("/health")
def health():
    return {"status": "ok", "service": "solar-manager-pro-api"}

@app.post("/api/v1/telemetry")
def ingest(payload: TelemetryIn, x_device_token: str = Header(default="")):
    if x_device_token != DEVICE_TOKEN:
        raise HTTPException(status_code=401, detail="Invalid device token")
    stamp = payload.timestamp or datetime.now(timezone.utc)
    panel_data = [p.model_dump() for p in payload.panels]
    total = sum(p["power_w"] for p in panel_data)
    db = SessionLocal()
    try:
        row = Telemetry(
            device_id=payload.device_id,
            site_id=payload.site_id,
            timestamp=stamp,
            total_power_w=total,
            panels=panel_data,
            battery=payload.battery.model_dump(),
        )
        db.add(row)
        db.commit()
        db.refresh(row)
        return {"ok": True, "id": row.id, "total_power_w": round(total, 3)}
    finally:
        db.close()

@app.get("/api/v1/telemetry/latest")
def latest(site_id: str = Query(default="my-home")):
    db = SessionLocal()
    try:
        row = db.query(Telemetry).filter(Telemetry.site_id == site_id).order_by(desc(Telemetry.timestamp)).first()
        if row is None:
            raise HTTPException(status_code=404, detail="No telemetry received for this site yet")
        return {
            "device_id": row.device_id,
            "site_id": row.site_id,
            "timestamp": row.timestamp.isoformat(),
            "total_power_w": row.total_power_w,
            "panels": row.panels,
            "battery": row.battery,
        }
    finally:
        db.close()

@app.get("/api/v1/telemetry/history")
def history(site_id: str = Query(default="my-home"), limit: int = Query(default=100, ge=1, le=1000)):
    db = SessionLocal()
    try:
        rows = db.query(Telemetry).filter(Telemetry.site_id == site_id).order_by(desc(Telemetry.timestamp)).limit(limit).all()
        return [{
            "timestamp": r.timestamp.isoformat(),
            "total_power_w": r.total_power_w,
            "panels": r.panels,
            "battery": r.battery,
        } for r in rows]
    finally:
        db.close()
