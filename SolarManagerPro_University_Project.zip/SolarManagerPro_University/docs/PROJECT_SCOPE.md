# Project Scope

## Objective
Design and implement a low-cost IoT monitoring prototype for a 12 V, 25 W solar setup using three separately measured PV modules (10 W, 10 W and 5 W).

## Measured parameters
- Each PV module: voltage, current, calculated power
- Battery measurement channel: voltage and signed current
- Total PV power: sum of individual panel powers
- Historical readings stored by the backend

## Network
ESP32 attempts the Home Wi-Fi profile first, then the phone hotspot profile. It posts telemetry to a cloud FastAPI endpoint over HTTPS. The Android app reads the latest site data from the backend.

## Academic evaluation
Demonstrate:
1. Sensor calibration against a multimeter.
2. Wi-Fi failover between router and hotspot.
3. Successful HTTPS telemetry upload.
4. Android app displaying live readings.
5. Backend history endpoint storing multiple samples.

## Not in initial scope
Commercial-grade authentication, remote inverter control, certified battery SOC, MPPT control, industrial safety certification, and guaranteed always-on cloud service.
