package com.solarmanagerpro

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.launch
import java.net.HttpURLConnection
import java.net.URL
import org.json.JSONObject

private val SolarGreen = Color(0xFF16834A)
private val PageBg = Color(0xFFF4F7F5)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("solar_config", MODE_PRIVATE)
        setContent { SolarApp(prefs) }
    }
}

data class PanelReading(val name: String, val rated: String, val voltage: String, val current: String, val power: String)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SolarApp(prefs: android.content.SharedPreferences) {
    var selected by remember { mutableStateOf("Dashboard") }
    var serverUrl by remember { mutableStateOf(prefs.getString("server_url", "") ?: "") }
    var siteId by remember { mutableStateOf(prefs.getString("site_id", "my-home") ?: "my-home") }
    var refreshCounter by remember { mutableIntStateOf(0) }
    val scope = rememberCoroutineScope()
    var status by remember { mutableStateOf("Demo mode — server not configured") }
    var totalPower by remember { mutableStateOf("--") }
    var batteryVoltage by remember { mutableStateOf("--") }
    var panels by remember {
        mutableStateOf(
            listOf(
                PanelReading("Panel 1", "10 W", "--", "--", "--"),
                PanelReading("Panel 2", "10 W", "--", "--", "--"),
                PanelReading("Panel 3", "5 W", "--", "--", "--")
            )
        )
    }
    var loading by remember { mutableStateOf(false) }
    val tabs = listOf("Dashboard", "Panels", "Analytics", "Connectivity", "Settings")

    MaterialTheme(
        colorScheme = lightColorScheme(primary = SolarGreen, secondary = Color(0xFFDBA52C), background = PageBg)
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text("Solar Manager Pro", fontWeight = FontWeight.Bold, fontSize = 19.sp)
                            Text("12 V • 25 W University Prototype", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    },
                    actions = { IconButton(onClick = { selected = "Connectivity" }) { Icon(Icons.Default.Wifi, "Connectivity") } }
                )
            },
            bottomBar = {
                NavigationBar {
                    val icons = listOf(Icons.Default.Dashboard, Icons.Default.Bolt, Icons.Default.ShowChart, Icons.Default.Wifi, Icons.Default.Settings)
                    tabs.forEachIndexed { index, tab ->
                        NavigationBarItem(
                            selected = selected == tab,
                            onClick = { selected = tab },
                            icon = { Icon(icons[index], contentDescription = tab) },
                            label = { Text(tab, fontSize = 10.sp) }
                        )
                    }
                }
            },
            containerColor = PageBg
        ) { padding ->
            when (selected) {
                "Dashboard" -> DashboardScreen(
                    Modifier.padding(padding), status, totalPower, batteryVoltage, panels,
                    onRefresh = { refreshCounter++ }, loading
                )
                "Panels" -> PanelsScreen(Modifier.padding(padding), panels)
                "Analytics" -> AnalyticsScreen(Modifier.padding(padding))
                "Connectivity" -> ConnectivityScreen(
                    Modifier.padding(padding), serverUrl, { serverUrl = it }, siteId, { siteId = it },
                    status, {
                        prefs.edit().putString("server_url", serverUrl.trim()).putString("site_id", siteId.trim()).apply()
                        status = "Server configuration saved on this phone"
                    },
                    onTest = {
                        scope.launch {
                            loading = true
                            status = "Testing server..."
                            val ok = withContext(Dispatchers.IO) { checkHealth(serverUrl.trimEnd('/')) }
                            status = if (ok) "Server is reachable" else "Server test failed — check URL / hosting"
                            loading = false
                        }
                    }, loading
                )
                else -> SettingsScreen(Modifier.padding(padding))
            }
        }

        LaunchedEffect(serverUrl, selected, refreshCounter) {
            if (selected == "Dashboard" && serverUrl.startsWith("https://")) {
                loading = true
                val result = withContext(Dispatchers.IO) { fetchLatest(serverUrl.trimEnd('/'), siteId) }
                if (result != null) {
                    totalPower = result.optString("total_power_w", "--")
                    batteryVoltage = result.optJSONObject("battery")?.optString("voltage_v", "--") ?: "--"
                    val arr = result.optJSONArray("panels")
                    if (arr != null) {
                        panels = (0 until minOf(3, arr.length())).map { i ->
                            val p = arr.getJSONObject(i)
                            PanelReading(
                                "Panel ${i + 1}", listOf("10 W", "10 W", "5 W")[i],
                                p.optString("voltage_v", "--"),
                                p.optString("current_a", "--"),
                                p.optString("power_w", "--")
                            )
                        }
                    }
                    status = "Connected — live server data"
                } else {
                    status = "Could not load server data"
                }
                loading = false
            }
        }
    }
}

private fun checkHealth(base: String): Boolean = try {
    if (!base.startsWith("https://")) return false
    val connection = (URL("$base/health").openConnection() as HttpURLConnection)
    connection.connectTimeout = 6000
    connection.readTimeout = 6000
    val ok = connection.responseCode in 200..299
    connection.disconnect()
    ok
} catch (_: Exception) { false }

private suspend fun fetchLatest(base: String, site: String): JSONObject? = try {
    val connection = (URL("$base/api/v1/telemetry/latest?site_id=$site").openConnection() as HttpURLConnection)
    connection.connectTimeout = 6000
    connection.readTimeout = 6000
    connection.requestMethod = "GET"
    val text = connection.inputStream.bufferedReader().use { it.readText() }
    connection.disconnect()
    JSONObject(text)
} catch (_: Exception) { null }

@Composable
fun DashboardScreen(
    modifier: Modifier, status: String, totalPower: String, batteryVoltage: String,
    panels: List<PanelReading>, onRefresh: () -> Unit, loading: Boolean
) {
    LazyColumn(modifier.fillMaxSize().padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(12.dp), contentPadding = PaddingValues(vertical = 14.dp)) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                Column {
                    Text("My Solar System", fontSize = 21.sp, fontWeight = FontWeight.Bold)
                    Text("Site: my-home", color = Color.Gray, fontSize = 12.sp)
                }
                AssistChip(onClick = {}, label = { Text(if (status.startsWith("Connected")) "Online" else "Not connected") }, leadingIcon = { Icon(Icons.Default.Circle, null, tint = if (status.startsWith("Connected")) SolarGreen else Color.Gray, modifier = Modifier.size(9.dp)) })
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                MetricCard("Total Solar Power", if (totalPower == "--") "-- W" else "$totalPower W", Icons.Default.WbSunny, Modifier.weight(1f))
                MetricCard("Battery Voltage", if (batteryVoltage == "--") "-- V" else "$batteryVoltage V", Icons.Default.BatteryChargingFull, Modifier.weight(1f))
            }
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(18.dp)) {
                Column(Modifier.padding(16.dp)) {
                    Text("Panel overview", fontWeight = FontWeight.Bold, fontSize = 17.sp)
                    Spacer(Modifier.height(10.dp))
                    panels.forEach { p ->
                        Row(Modifier.fillMaxWidth().padding(vertical = 7.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                            Column {
                                Text(p.name, fontWeight = FontWeight.SemiBold)
                                Text("Rated ${p.rated}", color = Color.Gray, fontSize = 12.sp)
                            }
                            Text(p.power + " W", fontWeight = FontWeight.Bold, color = SolarGreen)
                        }
                        HorizontalDivider()
                    }
                }
            }
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Color.White)) {
                Column(Modifier.padding(16.dp)) {
                    Text("Connection", fontWeight = FontWeight.Bold)
                    Text(status, color = Color.Gray, fontSize = 12.sp)
                    Spacer(Modifier.height(8.dp))
                    Button(onClick = onRefresh, enabled = !loading, modifier = Modifier.fillMaxWidth()) {
                        if (loading) CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp)
                        else Icon(Icons.Default.Refresh, null)
                        Spacer(Modifier.width(8.dp)); Text("Refresh data")
                    }
                }
            }
        }
        item { Text("Note: Live readings appear after ESP32 sensors and cloud server are configured.", color = Color.Gray, fontSize = 11.sp) }
    }
}

@Composable
fun MetricCard(title: String, value: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier) {
    Card(modifier, colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.padding(14.dp)) {
            Icon(icon, null, tint = SolarGreen)
            Spacer(Modifier.height(10.dp))
            Text(title, color = Color.Gray, fontSize = 11.sp)
            Text(value, fontSize = 23.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun PanelsScreen(modifier: Modifier, panels: List<PanelReading>) {
    LazyColumn(modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Text("Individual Panel Monitoring", fontSize = 20.sp, fontWeight = FontWeight.Bold) }
        items(panels) { p ->
            Card(colors = CardDefaults.cardColors(containerColor = Color.White)) {
                Column(Modifier.padding(16.dp)) {
                    Text("${p.name} • ${p.rated}", fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        ValueLabel("Voltage", "${p.voltage} V")
                        ValueLabel("Current", "${p.current} A")
                        ValueLabel("Power", "${p.power} W")
                    }
                }
            }
        }
        item { Text("Sensor calibration is required before using readings for an experiment.", color = Color.Gray, fontSize = 12.sp) }
    }
}

@Composable
fun ValueLabel(label: String, value: String) {
    Column {
        Text(label, color = Color.Gray, fontSize = 11.sp)
        Text(value, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
fun AnalyticsScreen(modifier: Modifier) {
    Column(modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("Energy Analytics", fontSize = 21.sp, fontWeight = FontWeight.Bold)
        Card(colors = CardDefaults.cardColors(containerColor = Color.White)) {
            Column(Modifier.padding(16.dp)) {
                Text("Daily generation", fontWeight = FontWeight.Bold)
                Text("Wh • Waiting for server data", color = Color.Gray, fontSize = 12.sp)
                Spacer(Modifier.height(16.dp))
                Canvas(Modifier.fillMaxWidth().height(130.dp)) {
                    val step = size.width / 7f
                    val values = listOf(.25f, .45f, .38f, .68f, .55f, .82f, .62f)
                    values.forEachIndexed { i, v ->
                        drawRoundRect(
                            color = SolarGreen.copy(alpha = .25f + v * .65f),
                            topLeft = androidx.compose.ui.geometry.Offset(i * step + 8, size.height * (1 - v)),
                            size = androidx.compose.ui.geometry.Size(step - 16, size.height * v),
                            cornerRadius = androidx.compose.ui.geometry.CornerRadius(8f, 8f)
                        )
                    }
                }
                Text("Illustrative chart layout — not measured data.", color = Color.Gray, fontSize = 11.sp)
            }
        }
        Card(colors = CardDefaults.cardColors(containerColor = Color.White)) {
            Column(Modifier.padding(16.dp)) {
                Text("Report periods", fontWeight = FontWeight.Bold)
                Text("Hourly • Daily • Weekly • Monthly", color = Color.Gray)
                Text("Historical reports become available after backend history endpoints are connected.", fontSize = 11.sp, color = Color.Gray)
            }
        }
    }
}

@Composable
fun ConnectivityScreen(
    modifier: Modifier, serverUrl: String, onServerUrl: (String) -> Unit,
    siteId: String, onSiteId: (String) -> Unit, status: String, onSave: () -> Unit,
    onTest: () -> Unit, loading: Boolean
) {
    LazyColumn(modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Text("Connectivity & Communication", fontSize = 20.sp, fontWeight = FontWeight.Bold) }
        item { Text("ESP32 Wi-Fi profiles are configured in firmware for this first prototype. The app connects to the cloud API.", color = Color.Gray, fontSize = 12.sp) }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Color.White)) {
                Column(Modifier.padding(16.dp)) {
                    Text("Network options", fontWeight = FontWeight.Bold)
                    listOf("Home Wi-Fi", "Mobile Hotspot", "Ethernet (gateway required)", "4G/5G (router or gateway required)", "Bluetooth provisioning (planned)").forEach {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Wifi, null, tint = SolarGreen, modifier = Modifier.size(19.dp))
                            Spacer(Modifier.width(10.dp))
                            Text(it, modifier = Modifier.weight(1f), fontSize = 13.sp)
                            Text(if (it.contains("planned")) "Planned" else "ESP32 / network", color = Color.Gray, fontSize = 10.sp)
                        }
                        Spacer(Modifier.height(8.dp))
                    }
                }
            }
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Color.White)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Server Configuration", fontWeight = FontWeight.Bold)
                    OutlinedTextField(value = serverUrl, onValueChange = onServerUrl, label = { Text("Backend URL (https://...)") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                    OutlinedTextField(value = siteId, onValueChange = onSiteId, label = { Text("Site ID") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                    Button(onClick = onSave, modifier = Modifier.fillMaxWidth()) { Text("Save configuration") }
                    OutlinedButton(onClick = onTest, modifier = Modifier.fillMaxWidth(), enabled = !loading) { Text("Test server connection") }
                    Text(status, color = Color.Gray, fontSize = 11.sp)
                }
            }
        }
    }
}

@Composable
fun SettingsScreen(modifier: Modifier) {
    Column(modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Settings", fontSize = 21.sp, fontWeight = FontWeight.Bold)
        listOf("System: 12 V DC", "Solar capacity: 25 W", "Panels: 10 W + 10 W + 5 W", "Device: ESP32-WROOM", "Project type: University prototype", "Data transport: HTTPS REST").forEach {
            Card(colors = CardDefaults.cardColors(containerColor = Color.White)) {
                Text(it, Modifier.fillMaxWidth().padding(16.dp), fontWeight = FontWeight.Medium)
            }
        }
        Text("This academic prototype does not yet implement account login, remote inverter control, or certified battery state-of-charge estimation.", color = Color.Gray, fontSize = 12.sp)
    }
}
